import cv2

#อ่าน
img = cv2.imread("image/Er2.jpg")
print(img)