import cv2
import numpy as np

# โหลดรูปภาพที่จะเปรียบเทียบ
image1 = cv2.imread('image/Er2.jpg')
image2 = cv2.imread('image/Er1.jpg')

# แปลงรูปภาพให้เป็นสีเทา
gray_image1 = cv2.cvtColor(image1, cv2.COLOR_BGR2GRAY)
gray_image2 = cv2.cvtColor(image2, cv2.COLOR_BGR2GRAY)

# คำนวณ Histogram ของรูปภาพ
hist_image1 = cv2.calcHist([gray_image1], [0], None, [256], [0, 256])
hist_image2 = cv2.calcHist([gray_image2], [0], None, [256], [0, 256])

# คำนวณค่าความคล้ายคลึงระหว่าง Histogram ของรูปภาพ
correlation = cv2.compareHist(hist_image1, hist_image2, cv2.HISTCMP_CORREL)
chisqr = cv2.compareHist(hist_image1, hist_image2, cv2.HISTCMP_CHISQR)
intersection = cv2.compareHist(hist_image1, hist_image2, cv2.HISTCMP_INTERSECT)
bhattacharyya = cv2.compareHist(hist_image1, hist_image2, cv2.HISTCMP_BHATTACHARYYA)

# แสดงค่าความคล้ายคลึงระหว่างรูปภาพ
print(f"Correlation: {correlation}")
print(f"Chi-Square: {chisqr}")
print(f"Intersection: {intersection}")
print(f"Bhattacharyya: {bhattacharyya}")
