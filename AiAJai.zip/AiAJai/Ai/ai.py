import cv2

#อ่าน
img = cv2.imread("image/Er1.jpg")
#img2 = cv2.imread("image/Er2.jpg")

#อ่านไฟล์ไว้แยกประเภท
brain_cascade = cv2.CascadeClassifier("imnew\classifier\cascade.xml")

gray_img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
#gray_img2 = cv2.cvtColor(img2,cv2.COLOR_BGR2GRAY)

#จำแนกสมอง
scaleFactor = 1.5
minNeighbors = 10
brain_detect = brain_cascade.detectMultiScale(gray_img,scaleFactor,minNeighbors)

#ลูปหาตำแหน่ง
for(x,y,w,h) in brain_detect:
    cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),thickness=3)

#แสดงผล
cv2.imshow("Original",img)
cv2.waitKey(0)
cv2.destroyAllWindows()