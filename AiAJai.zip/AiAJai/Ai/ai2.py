import cv2

# โหลดรูปภาพหลัก (main image) และรูปภาพที่จะเปรียบเทียบ (query image)
img = cv2.imread("image/Er2.jpg")
img2 = cv2.imread("image/Er1.jpg")

main_image = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
query_image = cv2.cvtColor(img2,cv2.COLOR_BGR2GRAY)

# สร้างตัวอย่าง ORB (Oriented FAST and Rotated BRIEF)
orb = cv2.ORB_create()

# ค้นหา key points และ descriptors ในรูปภาพหลักและรูปภาพที่จะเปรียบเทียบ
keypoints_main, descriptors_main = orb.detectAndCompute(main_image, None)
keypoints_query, descriptors_query = orb.detectAndCompute(query_image, None)

# สร้าง Brute-Force Matcher
bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

# ทำการ match descriptors ระหว่างรูปภาพหลักและรูปภาพที่จะเปรียบเทียบ
matches = bf.match(descriptors_main, descriptors_query)

# เรียงลำดับคู่ key points ตามความคล้ายคลึง
matches = sorted(matches, key=lambda x: x.distance)

# แสดง key points ที่คล้ายกัน
result_image = cv2.drawMatches(main_image, keypoints_main, query_image, keypoints_query, matches, outImg=None)

# แสดงรูปภาพที่มี key points ที่คล้ายกัน
cv2.imshow('Image Comparison', result_image)
cv2.waitKey(0)
cv2.destroyAllWindows()
